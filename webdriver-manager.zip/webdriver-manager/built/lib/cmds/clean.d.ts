import { Program } from '../cli';
export declare var program: Program;
