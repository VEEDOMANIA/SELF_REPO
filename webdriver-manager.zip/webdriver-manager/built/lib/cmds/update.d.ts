import { Program } from '../cli';
export declare let program: Program;
export declare function clearBrowserFile(): void;
