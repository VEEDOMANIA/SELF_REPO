import { Logger } from '../cli';
export declare function android(sdkPath: string, apiLevels: string[], architectures: string[], platforms: string[], acceptLicenses: boolean, version: string, oldAVDs: string[], logger: Logger, verbose: boolean): void;
export declare function iOS(logger: Logger): void;
