$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Feature.feature");
formatter.feature({
  "line": 2,
  "name": "Automate chrome (MOB_WEBAPP), native and hybrid mobile application in a Grid with Cucumber",
  "description": "",
  "id": "automate-chrome-(mob-webapp),-native-and-hybrid-mobile-application-in-a-grid-with-cucumber",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@AppUnitTest"
    }
  ]
});
formatter.scenarioOutline({
  "line": 5,
  "name": "Browse the Contact Us Page of TCS and Enter the details of query",
  "description": "",
  "id": "automate-chrome-(mob-webapp),-native-and-hybrid-mobile-application-in-a-grid-with-cucumber;browse-the-contact-us-page-of-tcs-and-enter-the-details-of-query",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 4,
      "name": "@chromeapplication"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "The URL of TCS Website \"\u003ccolumn\u003e\"",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "Browse the site and move to Contact Us page \"\u003ccolumn\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Enter the details for required fields \"\u003ccolumn\u003e\"",
  "keyword": "And "
});
formatter.examples({
  "line": 10,
  "name": "",
  "description": "",
  "id": "automate-chrome-(mob-webapp),-native-and-hybrid-mobile-application-in-a-grid-with-cucumber;browse-the-contact-us-page-of-tcs-and-enter-the-details-of-query;",
  "rows": [
    {
      "cells": [
        "column"
      ],
      "line": 11,
      "id": "automate-chrome-(mob-webapp),-native-and-hybrid-mobile-application-in-a-grid-with-cucumber;browse-the-contact-us-page-of-tcs-and-enter-the-details-of-query;;1"
    },
    {
      "cells": [
        "1"
      ],
      "line": 12,
      "id": "automate-chrome-(mob-webapp),-native-and-hybrid-mobile-application-in-a-grid-with-cucumber;browse-the-contact-us-page-of-tcs-and-enter-the-details-of-query;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 12,
  "name": "Browse the Contact Us Page of TCS and Enter the details of query",
  "description": "",
  "id": "automate-chrome-(mob-webapp),-native-and-hybrid-mobile-application-in-a-grid-with-cucumber;browse-the-contact-us-page-of-tcs-and-enter-the-details-of-query;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@AppUnitTest"
    },
    {
      "line": 4,
      "name": "@chromeapplication"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "The URL of TCS Website \"1\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "Browse the site and move to Contact Us page \"1\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Enter the details for required fields \"1\"",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 24
    }
  ],
  "location": "StepDefinition.chrome_application_launched(String)"
});
formatter.result({
  "duration": 42900868426,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 45
    }
  ],
  "location": "StepDefinition.chrome_application_processed(String)"
});
formatter.result({
  "duration": 104495444246,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 39
    }
  ],
  "location": "StepDefinition.chrome_application_closed(String)"
});
formatter.result({
  "duration": 3538475941,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 15,
  "name": "Browse through the Telecom Application to recharge Page",
  "description": "",
  "id": "automate-chrome-(mob-webapp),-native-and-hybrid-mobile-application-in-a-grid-with-cucumber;browse-through-the-telecom-application-to-recharge-page",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 14,
      "name": "@nativeapplication"
    }
  ]
});
formatter.step({
  "line": 16,
  "name": "Native application from a Telecom Company - Aircel \"\u003ccolumn\u003e\"",
  "keyword": "Given "
});
formatter.step({
  "line": 17,
  "name": "Open the application and browse recharge Packs \"\u003ccolumn\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 18,
  "name": "Enter PromoCode to complete the test \"\u003ccolumn\u003e\"",
  "keyword": "And "
});
formatter.examples({
  "line": 20,
  "name": "",
  "description": "",
  "id": "automate-chrome-(mob-webapp),-native-and-hybrid-mobile-application-in-a-grid-with-cucumber;browse-through-the-telecom-application-to-recharge-page;",
  "rows": [
    {
      "cells": [
        "column"
      ],
      "line": 21,
      "id": "automate-chrome-(mob-webapp),-native-and-hybrid-mobile-application-in-a-grid-with-cucumber;browse-through-the-telecom-application-to-recharge-page;;1"
    },
    {
      "cells": [
        "1"
      ],
      "line": 22,
      "id": "automate-chrome-(mob-webapp),-native-and-hybrid-mobile-application-in-a-grid-with-cucumber;browse-through-the-telecom-application-to-recharge-page;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 22,
  "name": "Browse through the Telecom Application to recharge Page",
  "description": "",
  "id": "automate-chrome-(mob-webapp),-native-and-hybrid-mobile-application-in-a-grid-with-cucumber;browse-through-the-telecom-application-to-recharge-page;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@AppUnitTest"
    },
    {
      "line": 14,
      "name": "@nativeapplication"
    }
  ]
});
formatter.step({
  "line": 16,
  "name": "Native application from a Telecom Company - Aircel \"1\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 17,
  "name": "Open the application and browse recharge Packs \"1\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 18,
  "name": "Enter PromoCode to complete the test \"1\"",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 52
    }
  ],
  "location": "StepDefinition.native_application_launched(String)"
});
formatter.result({
  "duration": 17273672247,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 48
    }
  ],
  "location": "StepDefinition.native_application_processed(String)"
});
formatter.result({
  "duration": 22144283372,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 38
    }
  ],
  "location": "StepDefinition.native_application_closed(String)"
});
formatter.result({
  "duration": 1689337156,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 25,
  "name": "Open a Hybrid application and work with its Native and Hybrid Context",
  "description": "",
  "id": "automate-chrome-(mob-webapp),-native-and-hybrid-mobile-application-in-a-grid-with-cucumber;open-a-hybrid-application-and-work-with-its-native-and-hybrid-context",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 24,
      "name": "@Hybridapplication"
    }
  ]
});
formatter.step({
  "line": 26,
  "name": "A Hybrid application and a URL of TCS website to process \"\u003ccolumn\u003e\"",
  "keyword": "Given "
});
formatter.step({
  "line": 27,
  "name": "Open the application to input URL of TCS website in native mode \"\u003ccolumn\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 28,
  "name": "Browse Contact Us page and fill required fields in webview mode \"\u003ccolumn\u003e\"",
  "keyword": "And "
});
formatter.examples({
  "line": 30,
  "name": "",
  "description": "",
  "id": "automate-chrome-(mob-webapp),-native-and-hybrid-mobile-application-in-a-grid-with-cucumber;open-a-hybrid-application-and-work-with-its-native-and-hybrid-context;",
  "rows": [
    {
      "cells": [
        "column"
      ],
      "line": 31,
      "id": "automate-chrome-(mob-webapp),-native-and-hybrid-mobile-application-in-a-grid-with-cucumber;open-a-hybrid-application-and-work-with-its-native-and-hybrid-context;;1"
    },
    {
      "cells": [
        "1"
      ],
      "line": 32,
      "id": "automate-chrome-(mob-webapp),-native-and-hybrid-mobile-application-in-a-grid-with-cucumber;open-a-hybrid-application-and-work-with-its-native-and-hybrid-context;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 32,
  "name": "Open a Hybrid application and work with its Native and Hybrid Context",
  "description": "",
  "id": "automate-chrome-(mob-webapp),-native-and-hybrid-mobile-application-in-a-grid-with-cucumber;open-a-hybrid-application-and-work-with-its-native-and-hybrid-context;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@AppUnitTest"
    },
    {
      "line": 24,
      "name": "@Hybridapplication"
    }
  ]
});
formatter.step({
  "line": 26,
  "name": "A Hybrid application and a URL of TCS website to process \"1\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 27,
  "name": "Open the application to input URL of TCS website in native mode \"1\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 28,
  "name": "Browse Contact Us page and fill required fields in webview mode \"1\"",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 58
    }
  ],
  "location": "StepDefinition.hybrid_application_launched(String)"
});
formatter.result({
  "duration": 17460283870,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 65
    }
  ],
  "location": "StepDefinition.hybrid_application_processed(String)"
});
