package com.app.junit;

import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
		features ="src/test/resources/features/app_features",
		glue = "com.app.stepdef",
		strict = false,
		dryRun=false,
		plugin={"json:Reports/unitTest/junit/Result.json", "html:Reports/unitTest/html/"},
		tags = {"@AppUnitTest"},
		monochrome = true)

public class TestRunner {
}
