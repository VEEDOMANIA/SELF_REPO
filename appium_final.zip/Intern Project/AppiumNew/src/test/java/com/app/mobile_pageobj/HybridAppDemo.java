package com.app.mobile_pageobj;

import com.app.excelread.Readfile;
import com.app.weboperations.Webop;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidElement;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HybridAppDemo extends Webop{

	static AppiumDriver<AndroidElement> driver;
	static WebDriverWait wait;
	static HybridAppDemo obj = new HybridAppDemo();
	static List<HashMap<String,String>> data_hybrid = Readfile.data("src/test/resources/INPUT.xls", "APP_HYBRID");
	static List<HashMap<String,String>> data_config = Readfile.data("src/test/resources/INPUT.xls", "APP_CONFIGURATION");
	static List<HashMap<String,String>> data_identifiers = Readfile.data("src/test/resources/INPUT.xls", "APP_IDENTIFIERS");

	@Before
	public  void hybrid_launch() throws InterruptedException, IOException {
		try{
			driver = HybridAppDemo.launch_appium_hybrid(driver, data_config.get(0).get("PlatformName"), data_config.get(0).get("MobileOsVersion"), data_config.get(0).get("MobileDeviceName"), data_config.get(0).get("ChromeDriverVersion_HYBRID"), data_config.get(0).get("MobileAppPackage_HYBRID"), data_config.get(0).get("MobileAppActivity_HYBRID"), data_config.get(0).get("MobileAppUrl"));
			Thread.sleep(5000);
			HybridAppDemo.takescreenshot(driver, "HYBRID_APP", 1, "open_hybrid_app", "SUCCESS");
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			HybridAppDemo.takescreenshot(driver, "HYBRID_APP", 1, "open_hybrid_app", "FAILED");}
	}

	@Test
	public  void hybrid_operations() throws InterruptedException {
		try{

			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("com.webviewbrowser:id/et"))).sendKeys("http://www.tcs.com\n");

			try{
				driver.context("WEBVIEW_com.webviewbrowser");
			}
			catch(Exception e){
				driver.context("WEBVIEW_undefined");
			}

			System.out.println("Hybrid Webview Context: " + driver.getContext());
			Thread.sleep(5000);

			HybridAppDemo.click(driver, data_identifiers.get(0).get("Navbar_Toggle"), "xpath");
			HybridAppDemo.click(driver, data_identifiers.get(0).get("Contacts_Link_1"), "cssselector");
			HybridAppDemo.switchtoframe(driver, data_identifiers.get(0).get("Frame"),"xpath");
			HybridAppDemo.sendkeys(driver, data_identifiers.get(0).get("First_Name"),data_hybrid.get(0).get("First_Name") , "id");
			HybridAppDemo.sendkeys(driver, data_identifiers.get(0).get("Last_Name"), data_hybrid.get(0).get("Last_Name"), "id");
			HybridAppDemo.sendkeys(driver, data_identifiers.get(0).get("Email"), data_hybrid.get(0).get("Email"), "id");
			HybridAppDemo.sendkeys(driver, data_identifiers.get(0).get("Organization"), data_hybrid.get(0).get("Organization"), "id");
			HybridAppDemo.selectValue(driver, data_identifiers.get(0).get("Industry"), data_hybrid.get(0).get("Industry"),"id");
			HybridAppDemo.selectValue(driver, data_identifiers.get(0).get("Country"), data_hybrid.get(0).get("Country"),"id");
			HybridAppDemo.sendkeys(driver, data_identifiers.get(0).get("Phone_Number"), data_hybrid.get(0).get("Phone_Number"), "id");
			HybridAppDemo.selectValue(driver, data_identifiers.get(0).get("Category"),  data_hybrid.get(0).get("Category"),"id");

			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement chkbox = driver.findElement(By.id("chkUpdate"));
			js.executeScript("arguments[0].click();", chkbox);
			driver.switchTo().defaultContent();

			Long value = (Long) js.executeScript("return window.scrollX;");
			js.executeScript("window.scrollBy(" + -value + ", 100)");
			Thread.sleep(5000);

			HybridAppDemo.takescreenshot(driver, "HYBRID_APP", 1, "fill_form", "SUCCESS");
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			HybridAppDemo.takescreenshot(driver, "HYBRID_APP", 1, "fill_form", "FAILED");
		}
	}


	@After
	public  void hybrid_close() {
		System.out.println("Hybrid App Processed");
		driver.quit();
	}
}