package com.app.mobile_pageobj;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

import com.app.excelread.Readfile;
import com.app.weboperations.Webop;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.ui.WebDriverWait;

public class NativeAppDemo extends Webop{
	static AndroidDriver<AndroidElement> driver;
	static WebDriverWait wait;
	static NativeAppDemo obj = new NativeAppDemo();
	static List<HashMap<String,String>> data_config = Readfile.data("src/test/resources/INPUT.xls", "APP_CONFIGURATION");
	static List<HashMap<String,String>> data_native = Readfile.data("src/test/resources/INPUT.xls", "APP_NATIVE");
	static List<HashMap<String,String>> data_identifiers = Readfile.data("src/test/resources/INPUT.xls", "APP_IDENTIFIERS");

	@Before
	public  void native_launch() throws InterruptedException, IOException {
		try{
			driver = NativeAppDemo.launch_appium_native(driver, data_config.get(0).get("PlatformName"), data_config.get(0).get("MobileOsVersion"), data_config.get(0).get("MobileDeviceName"), data_config.get(0).get("ChromeDriverVersion"), data_config.get(0).get("MobileAppPackage"), data_config.get(0).get("MobileAppActivity"), data_config.get(0).get("MobileAppUrl")); 
			Thread.sleep(5000);
			NativeAppDemo.takescreenshot(driver, "NATIVE_APP", 1, "open_native_app", "SUCCESS");
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			NativeAppDemo.takescreenshot(driver, "NATIVE_APP", 1, "open_native_app", "FAILED");
		}


	}

	@Test
	public void native_operations() throws InterruptedException {
		try{
			NativeAppDemo.click(driver, data_identifiers.get(0).get("Recharge"), "xpath");
			NativeAppDemo.click(driver, data_identifiers.get(0).get("Next"), "xpath");
			NativeAppDemo.click(driver, data_identifiers.get(0).get("2G_Data_Packs"), "xpath");
			NativeAppDemo.click(driver, data_identifiers.get(0).get("3_Days"), "xpath");
			NativeAppDemo.sendkeys(driver, data_identifiers.get(0).get("Promo_Code"), data_native.get(0).get("Promo_Code"), "xpath");
			NativeAppDemo.click(driver, data_identifiers.get(0).get("Description"), "xpath");
			NativeAppDemo.takescreenshot(driver, "NATIVE_APP", 1, "browse_recharge_pack", "SUCCESS");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			NativeAppDemo.takescreenshot(driver, "NATIVE_APP", 1, "browse_recharge_pack", "FAILED");
		}
	}

	@After
	public void native_close() {
		System.out.println("Native App Processed");
		driver.quit();
	}

}
