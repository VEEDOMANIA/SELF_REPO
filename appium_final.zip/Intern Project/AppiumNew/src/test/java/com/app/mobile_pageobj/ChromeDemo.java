package com.app.mobile_pageobj;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import io.appium.java_client.android.AndroidDriver;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.app.excelread.Readfile;
import com.app.weboperations.Webop;

public class ChromeDemo extends Webop{

	static AndroidDriver<WebElement> driver;
	static WebDriverWait wait;

	static ChromeDemo obj = new ChromeDemo();
	
	static List<HashMap<String,String>> data_config = Readfile.data("src/test/resources/INPUT.xls", "APP_CONFIGURATION");
	static List<HashMap<String,String>> data_mob_web_app = Readfile.data("src/test/resources/INPUT.xls", "APP_MOB_WEB_APP");
	static List<HashMap<String,String>> data_identifiers = Readfile.data("src/test/resources/INPUT.xls", "APP_IDENTIFIERS");

	@Before
	public  void chrome_launch() throws InterruptedException, IOException
	{
		try{

			driver = ChromeDemo.launch_appium_mobwebopp(driver, data_config.get(0).get("PlatformName"), data_config.get(0).get("MobileOsVersion"), data_config.get(0).get("MobileDeviceName"), data_config.get(0).get("ChromeDriverVersion"), data_config.get(0).get("MobileBrowserName"), data_config.get(0).get("MobileAppUrl")); 
			ChromeDemo.takescreenshot(driver, "MOB_WEB_APP", 1, "opening_browser", "SUCCESS");
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			ChromeDemo.takescreenshot(driver, "MOB_WEB_APP", 1, "opening_browser", "FAILED");
		}
	} 

	@Test
	public  void chrome_operations() throws InterruptedException
	{
		try{
			wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.elementToBeClickable(By.className("navbar-toggle"))).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#mainNav > li:nth-child(12) > a"))).click();
			driver.switchTo().frame(driver.findElement(By.className("iframeheight")));
			
			ChromeDemo.sendkeys(driver, data_identifiers.get(0).get("First_Name"),data_mob_web_app.get(0).get("First_Name") , "id");
			ChromeDemo.sendkeys(driver, data_identifiers.get(0).get("Last_Name"), data_mob_web_app.get(0).get("Last_Name"), "id");
			ChromeDemo.sendkeys(driver, data_identifiers.get(0).get("Email"), data_mob_web_app.get(0).get("Email"), "id");
			ChromeDemo.sendkeys(driver, data_identifiers.get(0).get("Organization"), data_mob_web_app.get(0).get("Organization"), "id");
			ChromeDemo.selectValue(driver, data_identifiers.get(0).get("Industry"), data_mob_web_app.get(0).get("Industry"),"id");
			ChromeDemo.selectValue(driver, data_identifiers.get(0).get("Country"), data_mob_web_app.get(0).get("Country"),"id");
			ChromeDemo.sendkeys(driver, data_identifiers.get(0).get("Phone_Number"), data_mob_web_app.get(0).get("Phone_Number"), "id");
			ChromeDemo.selectValue(driver, data_identifiers.get(0).get("Category"),  data_mob_web_app.get(0).get("Category"),"id");

			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement chkbox = driver.findElement(By.id("chkUpdate"));
			js.executeScript("arguments[0].click();", chkbox);
			driver.switchTo().defaultContent();
			
			Long value = (Long) js.executeScript("return window.scrollX;");
			js.executeScript("window.scrollBy(" + -value + ", 100)");
			Thread.sleep(5000);
			
			ChromeDemo.takescreenshot(driver, "MOB_WEB_APP", 1, "fill_form", "SUCCESS");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			ChromeDemo.takescreenshot(driver, "MOB_WEB_APP", 1, "fill_form", "FAILED");
		}
	}

	@After
	public  void chrome_shutdown() throws InterruptedException
	{
		System.out.println("Chrome Processed");
		driver.quit();
	}
}
