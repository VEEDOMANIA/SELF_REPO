package com.app.stepdef;

import java.util.HashMap;
import java.util.List;

import com.app.excelread.Readfile;
import com.app.mobile_pageobj.ChromeDemo;
import com.app.mobile_pageobj.HybridAppDemo;
import com.app.mobile_pageobj.NativeAppDemo;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class StepDefinition {

	ChromeDemo chromedemo = new ChromeDemo();
	NativeAppDemo nativedemo = new NativeAppDemo();
	HybridAppDemo hybriddemo = new HybridAppDemo();

	static List<HashMap<String,String>> data_config = Readfile.data("src/test/resources/INPUT.xls", "APP_CONFIGURATION");
	static List<HashMap<String,String>> data_mob_web_app = Readfile.data("src/test/resources/INPUT.xls", "APP_MOB_WEB_APP");
	static List<HashMap<String,String>> data_native = Readfile.data("src/test/resources/INPUT.xls", "APP_NATIVE");
	static List<HashMap<String,String>> data_hybrid = Readfile.data("src/test/resources/INPUT.xls", "APP_HYBRID");

	@Given("^The URL of TCS Website \"([^\"]*)\"$")
	public void chrome_application_launched(String arg1) throws Throwable {
		if(data_config.get(0).get("MOB_WEB_APP").equals("YES"))
		{
			if(data_mob_web_app.get(0).get("EXECUTE ?").equals("YES")){
				chromedemo.chrome_launch();
			}
		}
	}

	@Then("^Browse the site and move to Contact Us page \"([^\"]*)\"$")
	public void chrome_application_processed(String arg1) throws Throwable {
		if(data_config.get(0).get("MOB_WEB_APP").equals("YES"))
		{
			if(data_mob_web_app.get(0).get("EXECUTE ?").equals("YES")){
				chromedemo.chrome_operations();
			}
		}
	}

	@And("^Enter the details for required fields \"([^\"]*)\"$")
	public void chrome_application_closed(String arg1) throws Throwable {
		if(data_config.get(0).get("MOB_WEB_APP").equals("YES"))
		{
			if(data_mob_web_app.get(0).get("EXECUTE ?").equals("YES")){
				chromedemo.chrome_shutdown();
			}
		}

	}

	@Given("^Native application from a Telecom Company - Aircel \"([^\"]*)\"$")
	public void native_application_launched(String arg1) throws Throwable {
		if(data_config.get(0).get("NATIVE").equals("YES"))
		{
			if(data_native.get(0).get("EXECUTE ?").equals("YES")){
				nativedemo.native_launch();
			}
		}
	}

	@Then("^Open the application and browse recharge Packs \"([^\"]*)\"$")
	public void native_application_processed(String arg1) throws Throwable {
		if(data_config.get(0).get("NATIVE").equals("YES"))
		{
			if(data_native.get(0).get("EXECUTE ?").equals("YES")){
				nativedemo.native_operations();
			}
		}
	}

	@And("^Enter PromoCode to complete the test \"([^\"]*)\"$")
	public void native_application_closed(String arg1) throws Throwable {
		if(data_config.get(0).get("NATIVE").equals("YES"))
		{
			if(data_native.get(0).get("EXECUTE ?").equals("YES")){
				nativedemo.native_close();
			}
		}

	}

	@Given("^A Hybrid application and a URL of TCS website to process \"([^\"]*)\"$")
	public void hybrid_application_launched(String arg1) throws Throwable {
		if(data_config.get(0).get("HYBRID").equals("YES"))
		{
			if(data_hybrid.get(0).get("EXECUTE ?").equals("YES")){
				hybriddemo.hybrid_launch();
			}
		}
	}

	@Then("^Open the application to input URL of TCS website in native mode \"([^\"]*)\"$")
	public void hybrid_application_processed(String arg1) throws Throwable {
		if(data_config.get(0).get("HYBRID").equals("YES"))
		{
			if(data_hybrid.get(0).get("EXECUTE ?").equals("YES")){
				hybriddemo.hybrid_operations();
			}
		}
	}

	@And("^Browse Contact Us page and fill required fields in webview mode \"([^\"]*)\"$")
	public void hybrid_application_closed(String arg1) throws Throwable {
		if(data_config.get(0).get("HYBRID").equals("YES"))
		{
			if(data_hybrid.get(0).get("EXECUTE ?").equals("YES")){
				hybriddemo.hybrid_close();
			}
		}
	}
}
