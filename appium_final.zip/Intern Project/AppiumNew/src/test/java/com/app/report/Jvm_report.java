package com.app.report;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

public class Jvm_report {

	public static void main(String args[])
	{
		Jvm_report.extract_report();
	}

	public static void extract_report()
	{
		File reportOutputDirectory = new File("target/cucumber");
		List<String> jsonFiles = new ArrayList<String>();
		jsonFiles.add("Reports/unitTest/junit/Result.json");
		//jsonFiles.add("cucumber-report-2.json");

		String jenkinsBasePath = "";
		String buildNumber = "1";
		String projectName = "APP";
		boolean skippedFails = true;
		boolean pendingFails = false;
		boolean undefinedFails = true;
		boolean runWithJenkins = false;
		boolean parallelTesting = false;

		Configuration configuration = new Configuration(reportOutputDirectory, projectName);
		// optionally only if you need
		configuration.setStatusFlags(skippedFails, pendingFails, undefinedFails, parallelTesting);
		configuration.setParallelTesting(parallelTesting);
		configuration.setJenkinsBasePath(jenkinsBasePath);
		configuration.setRunWithJenkins(runWithJenkins);
		configuration.setBuildNumber(buildNumber);

		ReportBuilder reportBuilder = new ReportBuilder(jsonFiles, configuration);
		reportBuilder.generateReports();
	}
}