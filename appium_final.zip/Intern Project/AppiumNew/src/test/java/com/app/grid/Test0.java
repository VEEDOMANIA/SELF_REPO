package com.app.grid;

import io.appium.java_client.android.AndroidDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.*;
 
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
 
public class Test0 {
 
private AndroidDriver<WebElement> driver1;
private ArrayList<AndroidDriver<WebElement>> driver2;

 
	 public ArrayList<AndroidDriver<WebElement>> driverSetup(AndroidDriver<WebElement> driver,String[] pname,String[] pversion,String[] dname, String[] appname) throws MalformedURLException{
		
		for(int i = 0; i < dname.length; i++) {
			 DesiredCapabilities  temp = DesiredCapabilities.chrome(); //new DesiredCapabilities();
			 temp.setCapability("platformName", pname[i]);
			 temp.setCapability("platformVersion", pversion[i]);
			 temp.setCapability("deviceName", dname[i]);
			 temp.setCapability("applicationName", appname[i]);
			 temp.setCapability("browserName", "Chrome");
			 
			 System.out.println("pname: " + temp.getCapability("platformName"));
			 System.out.println("pversion: " + temp.getCapability("platformVersion"));
			 System.out.println("dname: " + temp.getCapability("deviceName"));
			 System.out.println("appname: " + temp.getCapability("applicationName"));
			 System.out.println("browsername: " + temp.getCapability("browserName"));
			 System.out.println(temp);
			 driver = new AndroidDriver<WebElement>(new URL("http://192.168.0.112:4000/wd/hub"), temp);
			 driver.get("http://www.google.com");
		}
		
		 return driver2;
	 }
  
	 @Test
	 public void f() throws MalformedURLException {
		 String[] appname1 = {"Asus", "Redmi"};
		 String[] pname1 = {"Android", "Android"};
		 String[] pversion1 = {"6.0.1", "4.2.2"};
		 String[] dname1 = {"device", "device"};
		 driver2 = driverSetup(driver1, pname1, pversion1, dname1, appname1);
	 }
 
}